const axios = require('axios');
const token = 'token placeholder';
const { Client, Intents } = require('discord.js');
const region_data = require('./region_data');
const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES] });
const prefix = '!'
let locations =[];
function capitalizeFirstLetter(str) {
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}

client.once('ready', ()  => {
  console.log('Covid_bot ready');
  for (let s in region_data){
    locations.push(s);
  }
});


let validate = false;
client.on('message', async msg => {
  let address = 'https://api.opencovid.ca/summary?stat=cases&';
  if (!msg.content.startsWith(prefix)){
    return;
  }
  let args = msg.content.slice(prefix.length).trim().split(' ');
  let command = args.shift().toLowerCase();
  for (let i=0;i<args.length;i++){
    switch (args[i].toLowerCase()){
      case 'in':
        loc=region_data[capitalizeFirstLetter(args[i+1])];
        if (region_data.hasOwnProperty(capitalizeFirstLetter(args[i+1]))){
          address += `loc=${loc}&`;
          validate = true;
        }

        break;
      case 'on':
        date = args[i+1];
        address += `date=${date}&`;
        break;
    }
  }

  if (command==='data'){
    let getData = async () => {
      let response = await axios.get(address);
      let d = response.data
      return d
    }
    let data_value = await getData();
    if (validate) {
      for (let p in data_value.summary[0]){
        msg.channel.send(`${p} : ${data_value.summary[0][p]}`);
      }
    }
    else{
      msg.channel.send('invalid location. see !help for list of all locations.');
    }
  }
  else if (command==='help'){
    console.log(true);
    for (let s of locations){
      msg.channel.send(s);
    }
  }
});

client.login(token);
